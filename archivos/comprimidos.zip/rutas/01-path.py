from pathlib import Path

path = Path(r"hola-mundo\mi-archivo.py")
path.is_file()
path.is_dir()
path.exists()