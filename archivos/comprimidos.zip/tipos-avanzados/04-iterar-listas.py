
MASCOTAS = ["Pelusa", "Pulga", "Felipe", "Chanchito feliz"]

for indice, mascota in enumerate(MASCOTAS):
    print(indice, mascota)