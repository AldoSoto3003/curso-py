
MASCOTAS = ["Pelusa", "Pulga", "Felipe", "Chanchito feliz"]

if "wolfgang" in MASCOTAS:
    print(MASCOTAS.index("Pulga"))
