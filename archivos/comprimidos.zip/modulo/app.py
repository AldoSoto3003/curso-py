
from usuarios.impuestos.utilidades import pagar_impuestos
# import usuarios


# print(dir(usuarios))
# print(usuarios.__name__)
# print(usuarios.__package__)
# print(usuarios.__path__)
# print(usuarios.__file__)

print(__name__)
pagar_impuestos()