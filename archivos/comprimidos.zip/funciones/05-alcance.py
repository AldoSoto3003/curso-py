""" Alcance de funciones """

def saludar():
    saludo = "Hola mundo"
    
def saludaChanchito():
    saludo = "Hola chanchito"
    
print(saludo)