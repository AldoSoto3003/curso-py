""" 04 Return """

def suma(a,b):
    resultado = a + b
    return resultado
    
c = suma(1,2)
print(c)
