""" If """

EDAD = 22

if EDAD > 54:
    print("Puede ver la pelicula con descuento")
elif EDAD > 17:
    print("Puedes ver la pelicula")
else:
    print("No puedes entrar")

print("Listo")