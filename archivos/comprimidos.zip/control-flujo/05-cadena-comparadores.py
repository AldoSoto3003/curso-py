""" 05 Cadenas comparadores"""

EDAD = 25

if 15 <= EDAD <= 65:
    print("Puede entrar a la piscina")

