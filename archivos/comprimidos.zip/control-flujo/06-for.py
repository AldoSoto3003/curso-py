""" For else """

BUSCAR = 31
for numero in range(5):
    if numero == BUSCAR:
        print("encontrado",BUSCAR)
        break
else:
    print("No encontré el numero buscado :(")
    

for char in "Ultimate python":
    print(char)