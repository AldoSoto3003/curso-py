""" while """

# NUMERO = 1
# while NUMERO < 100:
#     print(NUMERO)
#     NUMERO *= 2

comando = ""

while True:
    comando = input("$ ")
    print(comando)