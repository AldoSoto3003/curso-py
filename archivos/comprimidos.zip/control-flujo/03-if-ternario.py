"""If ternario"""

EDAD = 15

MENSAJE = "Es mayor" if EDAD > 17 else "es menor"

# if EDAD > 17:
#     MENSAJE = "Es mayor"
# else:
#     MENSAJE = "Es menor"    

print(MENSAJE)