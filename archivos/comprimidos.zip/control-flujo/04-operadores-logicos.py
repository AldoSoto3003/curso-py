# and, or, not

GAS = False
ENCENDIDO = True
EDAD = 18

if not GAS or ENCENDIDO or EDAD > 17:
    print("Puedes avanzar")