"""Clase_de_metodos_de_string"""

ANIMAL = "   chanCHito feliz  "
print(ANIMAL.upper())
print(ANIMAL.lower())
print(ANIMAL.title())
print(ANIMAL.strip().capitalize())
print(ANIMAL.strip())
print(ANIMAL.find("i"))
print(ANIMAL.replace("CH","j"))
print("nCH" in ANIMAL)
print("nCH" not in ANIMAL)






