NOMBRE_CURSO = "python"
print(NOMBRE_CURSO)
