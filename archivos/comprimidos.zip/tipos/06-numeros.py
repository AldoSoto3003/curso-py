"""Numeros"""

NUMERO = 2 #Entero
DECIMAL = 1.2 #Decimal
IMAGINARIO = 2 + 2j # 2 + 2i

NUMERO += 2

print(f"Suma -> {1 + 3}")
print(f"Resta -> {1 - 3}")
print(f"Multiplicacion -> {1 * 3}")
print(f"Division -> {1 / 3}")
print(f"Division entera -> {1 // 3}")
print(f"Potencia -> {2 ** 3}")






