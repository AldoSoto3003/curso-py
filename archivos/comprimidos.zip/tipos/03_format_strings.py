nombre = "Aldo"
apellido = "Soto"
nombre_completo = nombre + " " + apellido
nombre_completo = f"{nombre} {apellido}" 


print(nombre_completo)