nombre_curso = "Ultimate Python"
descripcion_curso = """
Ultimate python,
este curso contempla todos los detalles
que necesitas aprender para encontrar trabajo 
como programador.
"""

print(nombre_curso, descripcion_curso)
print(nombre_curso[0])
print(nombre_curso[9:])
print(nombre_curso[:])

