"""Secuencias_de_escape"""

CURSO = "Ultimate \n \"Python\""
print(CURSO)
