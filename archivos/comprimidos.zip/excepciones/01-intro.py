
try:
    n1 = int(input("Ingresa primer numero: "))
except:
    print("Ocurrio un error :(")