
try:
    n1 = int(input("Ingresa primer numero: "))
    asdasd
except ValueError as e:
    print(type(e))
except NameError as e:
    print(type(e))